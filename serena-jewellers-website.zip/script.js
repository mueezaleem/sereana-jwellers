const header = document.querySelector('.site-header');
const menuBtn = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav-links');

const updateHeader = () => header.classList.toggle('scrolled', window.scrollY > 30);
updateHeader();
window.addEventListener('scroll', updateHeader, { passive: true });

menuBtn.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuBtn.setAttribute('aria-expanded', String(open));
});

document.querySelectorAll('.nav-links a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuBtn.setAttribute('aria-expanded', 'false');
}));

const phone = '923009893968';
document.querySelectorAll('[data-service]').forEach(card => {
  const service = card.dataset.service;
  const message = `Hello Serena Jewellers, I am interested in ${service}. Could you please share the price/details and available timings?`;
  card.href = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
  card.target = '_blank';
  card.rel = 'noopener';
});

const reveal = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      reveal.unobserve(entry.target);
    }
  });
}, { threshold: .12 });

document.querySelectorAll('.reveal').forEach(el => reveal.observe(el));
document.getElementById('year').textContent = new Date().getFullYear();
