SERENA JEWELLERS WEBSITE
========================

Files
- index.html  : Website content and structure
- styles.css : All styling and responsive layout
- script.js  : Mobile menu, scroll effects, service WhatsApp links

Verified business details used
- Business: Serena Jewellers
- Category: Jewellery store / Jewellery designer
- Address: Shop #6, Block 12-E, Jinnah Super Market, F-7 Markaz, Islamabad 44000, Pakistan
- Phone / WhatsApp: +92 300 9893968
- Current Maps rating at build time: 4.5 / 5 from 25 reviews
- Listed hours: Monday-Saturday, 11:15 AM-9:00 PM
- Sunday: not listed in available Maps data (site says "call first" instead of inventing a time)

Additional directory categories referenced for services
- Gemstones
- Jewellery designers
- Jewellery repairing
- Diamonds
- Gold jewellery
- Gold / silver / platinum
- Precious and semi-precious stones
- Wedding jewellery

Images
The presentation uses remote editorial images from Unsplash so the ZIP stays lightweight and easy to edit. They are not represented as photos of Serena Jewellers' actual inventory. Replace the three image URLs in index.html / styles.css with the business's own photography whenever available.

Editing
1. Open index.html in any editor.
2. Change text directly in the relevant section.
3. Change WhatsApp number in index.html and the `phone` variable in script.js if needed.
4. Change colors in the :root section at the top of styles.css.
5. Replace gallery and hero image URLs with your own images.

No build tools or frameworks are required. Open index.html directly in a browser or upload all files to any standard web host.
